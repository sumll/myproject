<template>
  <div class="404">
    <h1>404 Not Found.</h1>
  </div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'NotFound'
})
</script>

<style lang="scss" scoped></style>
