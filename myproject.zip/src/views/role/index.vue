<template>
  <div class="role">角色管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'LoginIndex'
})
</script>

<style lang="scss" scoped></style>
