<template>
  <div class="advert">广告管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'AdvertIndex'
})
</script>

<style lang="scss" scoped></style>
