<template>
  <div class="advert-space">广告位管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'AdvertSpaceIndex'
})
</script>

<style lang="scss" scoped></style>
